import React from 'react'

const Footer = () => {
    return (
        <div>
            <br></br>
            <hr></hr>
            <p className="footer-text">Made with ♥️ by Darshan<br></br>
            <br></br>
            <small>All rights reserved © 2022 Darshan Shinde</small><br></br>
            {/* <small>Illustrations by undraw.co</small> */}
            </p>
        </div>
    )
}

export default Footer
